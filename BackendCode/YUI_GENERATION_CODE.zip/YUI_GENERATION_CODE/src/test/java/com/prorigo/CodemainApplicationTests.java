package com.prorigo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodemainApplicationTests {

	@Test
	void contextLoads() {
	}

}
