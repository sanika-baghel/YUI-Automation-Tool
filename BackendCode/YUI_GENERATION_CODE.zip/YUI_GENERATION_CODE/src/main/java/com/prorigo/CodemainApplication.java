package com.prorigo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodemainApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodemainApplication.class, args);
	}

}
